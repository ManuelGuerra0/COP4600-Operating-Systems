#include <libusb-1.0/libusb.h>
#include <linux/uinput.h>
#include <sys/stat.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#define VENDOR_ID 0x9A7A
#define PRODUCT_ID 0xBA17

void emit(int fd, int type, int code, int val) {
   struct input_event ie;		// Receives input event from parameters passed
   ie.type = type;
   ie.code = code;
   ie.value = val;
   write(fd, &ie, sizeof(ie));	// POSIX call to write to the js0 file
}

int main() {
	libusb_device **devices; 				// double pointer of device which gets list of devices
	libusb_device_handle *device_handle; 	// a device handle
	libusb_context *session = NULL; 		// a libusb session
	int usbInit = libusb_init(&session); 	// initializes the library for our session
	if (usbInit < 0) {
		printf("LibUSB initialization error!\n");
		return 1;
	}

	libusb_set_debug(session, 3); 									// recommended verbosity level
	ssize_t numDevList = libusb_get_device_list(session, &devices); // obtains list of devices
	if (numDevList < 0) {
		printf("Unable to get device!\n");
		return 1;
	}
	
	printf("%zu devices are in the list!\n", numDevList);
	device_handle = libusb_open_device_with_vid_pid(session, VENDOR_ID, PRODUCT_ID);
	if (device_handle == NULL) {			// finds device with vid 0x9A7A and pid 0xBA17
		printf("Unable to open device!\n");
	} else {
		printf("Device has been opened!\n");
	}
	
	libusb_free_device_list(devices, 1); 							// frees list of devices not needed
	if (libusb_kernel_driver_active(device_handle, 0) == 1) { 		// checks for driver
		printf("Kernel driver is now active!\n");
		if (libusb_detach_kernel_driver(device_handle, 0) == 0) { 	// detaches the driver
			printf("Kernel driver is now detached!\n");
		}
	}
	
	usbInit = libusb_claim_interface(device_handle, 0); // claims interface 0 of device (joystick needs)
	if (usbInit < 0) {
		printf("Unable to claim interface!\n");
		return 1;
	}
	printf("Interface has now been claimed!\n");

   	struct uinput_user_dev uud;								// Creates virtual joystick
   	int version;
   	int fd = open("/dev/uinput", O_WRONLY | O_NONBLOCK);	// POSIX call to access location of js0 file
   	int rc = ioctl(fd, UI_GET_VERSION, &version);

   	ioctl(fd, UI_SET_ABSBIT, ABS_X); 	// The ioctls will enable the device that is about to be
   	ioctl(fd, UI_SET_ABSBIT, ABS_Y); 	// created, to pass key events, in this case the space key.
   	ioctl(fd, UI_SET_EVBIT, EV_ABS);	// Informs the joystick what events it will have.
   	ioctl(fd, UI_SET_EVBIT, EV_KEY);
   	ioctl(fd, UI_SET_KEYBIT, BTN_JOYSTICK);

   	memset(&uud, 0, sizeof(uud));
   	uud.id.bustype = BUS_USB;
   	uud.id.vendor = VENDOR_ID;
   	uud.id.product = PRODUCT_ID;
   	snprintf(uud.name, UINPUT_MAX_NAME_SIZE, "uinput old interface");
   	write(fd, &uud, sizeof(uud));
   	ioctl(fd, UI_DEV_CREATE);

   	uud.absmin[ABS_X] = -1;		// Define max and min for X and Y since they are absolute
   	uud.absmin[ABS_Y] = -1;
   	uud.absmax[ABS_X] = 1;
   	uud.absmax[ABS_Y] = 1;
   	uud.absfuzz[ABS_X] = 0;
   	uud.absfuzz[ABS_Y] = 0;
   	uud.absflat[ABS_X] = 0;
   	uud.absflat[ABS_Y] = 0;

	bool read = true;		// TRUE if interface is reading, FALSE is not
	int byteValue;			// used to make bitwise operations
	int realBytes;			// # of bytes actually written
	unsigned char buffer; 	// buffer for joystick to write byte data (1 byte = 1 character)

	while (read) { // Key press, report the event, send key release, and report again
		usbInit = libusb_interrupt_transfer(device_handle, 1| LIBUSB_ENDPOINT_IN, &buffer, 1, &realBytes, 0);
		if (realBytes == 1 && usbInit == 0) {			// interrupt transfer waits for events
			printf("----------------------------------------------\n");
			printf("Raw: 0x%x /", buffer);				// raw data of uinput
			byteValue = buffer & 0b10000;
			if (byteValue == 0b10000) {
				emit(fd, EV_KEY, BTN_JOYSTICK, 1);		// button is ON
				printf(" Button: On /");
			} else {
				emit(fd, EV_KEY, BTN_JOYSTICK, 0);		// button is OFF
				printf(" Button: Off /");
			}
				emit(fd, EV_SYN, SYN_REPORT, 0);
			byteValue = buffer & 0b0100;
			if (byteValue == 0b0100) {
				emit(fd, EV_ABS, ABS_X, -32767);		// X is LEFT
				emit(fd, EV_SYN, SYN_REPORT, 0);
				printf(" X: Left /");
			}
			byteValue = buffer & 0b1100;
			if (byteValue == 0b1100) {
				emit(fd, EV_ABS, ABS_X, 32767);			// X is RIGHT
				emit(fd, EV_SYN, SYN_REPORT, 0);
				fflush(stdout);
                printf("\b\b\b\b\b\bRight /");
               	fflush(stdout);
			}
			else if (byteValue == 0b1000) {
				emit(fd, EV_ABS, ABS_X, 0);				// X is MIDDLE
				emit(fd, EV_SYN, SYN_REPORT, 0);
				printf(" X: Middle /");
			}
			byteValue = buffer & 0b01;
			if (byteValue == 0b01) {
				emit(fd, EV_ABS, ABS_Y, 32767);			// Y is DOWN
				emit(fd, EV_SYN, SYN_REPORT, 0);
				printf(" Y: Down");
			}
			byteValue = buffer & 0b11;
			if (byteValue == 0b11) {
				emit(fd, EV_ABS, ABS_Y, -32767);		// Y is UP
				emit(fd, EV_SYN, SYN_REPORT, 0);
				fflush(stdout);
               	printf("\b\b\b\bUp  ");
               	fflush(stdout);
			}
			else if (byteValue == 0b10) {
				emit(fd, EV_ABS, ABS_Y, 0);				// Y is MIDDLE
				emit(fd, EV_SYN, SYN_REPORT, 0);
				printf(" Y: Middle");
			}
			printf("\n");
		} else {
			printf("There seems to be an error!\n");
			read = false;
		}
	}
	printf("You have exited the program!\n");
	usbInit = libusb_release_interface(device_handle, 0);	// ejects interface
	if (usbInit != 0) {
		return 1;
	}
	libusb_close(device_handle);
	libusb_exit(session);
	return 0;
}