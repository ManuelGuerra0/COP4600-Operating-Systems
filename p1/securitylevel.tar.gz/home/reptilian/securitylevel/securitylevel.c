#define _GNU_SOURCE
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/syscall.h>

#include "securitylevel.h"
#define GET 332
#define SET 333

int get_security_level(int pid){
  long result = syscall(GET,pid);
  printf("%ld", result);
  if (result >= 0) {
    return result;
  }
  else {
    return -1;
  }
}

int set_security_level(int pid, int new_level) {
  long result = syscall(SET,pid,new_level);
  if (result >= 0){
    return result;
  }
  else {
    return -1;
  }
}

int* retrieve_set_security_params(int pid, int new_level) {
  int* harness = (int*)malloc(4*sizeof(int));
  harness[0] = SET;
  harness[1] = 2;
  harness[2] = pid;
  harness[3] = new_level;
  return harness;
}

int* retrieve_get_security_params(int pid) {
  int* harness = (int*)malloc(3*sizeof(int));
  harness[0] = GET;
  harness[1] = 1;
  harness[2] = pid;
  return harness;
}

int interpret_set_security_result(int ret_value){
  return ret_value;
}

int interpret_get_security_result(int ret_value){
  return ret_value;
}
