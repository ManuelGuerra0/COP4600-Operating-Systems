#include <iostream>
#include "Wad.h"
using namespace std;

int main(){

	Wad* loadWad(const string &path);

	getMagic();

	isContent(const string &path);

	isDirectory(const string &path);

	getSize(const string &path);

	return 0;
}