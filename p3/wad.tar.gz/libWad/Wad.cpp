#include <iostream>
#include <stdio.h> 
#include <sys/stat.h>
#include "Wad.h"
using namespace std;

public static Wad* loadWad(const string &path){
	//create object to use other functions on itself's data
    //take in a file using binary
    //implment using hashmap? tree?
}

public string getMagic(){
	char *magicNum = new char[4];
	uint32_t descriptorNum;
    uint32_t offsetNum;
	return "";
}

public bool isContent(const string &path){
	struct stat buffer;
    stat(path, &buffer);
    return S_ISREG(buffer.st_mode);
}

public bool isDirectory(const string &path){
	struct stat buffer;
    stat(path, &buffer);
    return S_ISDIR(buffer.st_mode);
}

public int getSize(const string &path){
	// opening the file in read mode 
    FILE* fp = fopen(path, "r"); 
    // checking if the file exist or not 
    if (fp == NULL) { 
        printf("File Not Found!\n"); 
        return -1; 
    } 
    fseek(fp, 0L, SEEK_END);
    // calculating the size of the file 
    long int size = ftell(fp); 
    // closing the file 
    fclose(fp);

    return size;
}

public int getContents(const string &path, char *buffer, int length, int offset = 0){
	return 0;
}

public int getDirectory(const string &path, vector<string> *directory){
	return 0;
}