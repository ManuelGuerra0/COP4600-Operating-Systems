#ifndef WAD
#define WAD

public static Wad* loadWad(const string &path);

public string getMagic();

public bool isContent(const string &path);

public bool isDirectory(const string &path);

public int getSize(const string &path);

public int getContents(const string &path, char *buffer, int length, int offset = 0);

public int getDirectory(const string &path, vector<string> *directory);

#endif