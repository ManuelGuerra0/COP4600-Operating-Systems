#include <unistd.h>
#include <stdlib.h>
#include "classification.h"

int get_classification(const char *filename) {
	return syscall(333, filename);
}

int set_classification(const char *filename, int new_class) {
  	return syscall(332, filename, new_class);
}
