#include <jni.h>
#include <string>
#include "read_file.h"
using namespace std;

extern "C"
JNIEXPORT jstring

JNICALL
Java_edu_ufl_cise_os_p2_P2Activity_stringFromJNI(JNIEnv *env, jobject /* this */, jstring input) {

    // Assigns a pointer to array given by the read_file function
    char *pointer = read_file(env->GetStringUTFChars(input, 0));

    if(pointer == nullptr) {
        // WHEN FILE DOES NOT EXIST
        return env->NewStringUTF("Error: File Not Found\n");
    } else {
        // WHEN FILE DOES EXIST
        // Transfers contents of pointer to jstring so we can free memory
        jstring output = env->NewStringUTF(pointer);
        free(pointer);
        
        // Returns the result in jstring
        return output;
    }
}