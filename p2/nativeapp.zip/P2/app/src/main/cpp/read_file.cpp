#include <iostream>
#include <unistd.h>
#include "read_file.h"
using namespace std;

char *read_file(const char *filename){
    if (0 == access(filename, 0)) { 
        // FILE DOES EXIST
        FILE *f = fopen(filename, "r");
        
        // Gets file size
        fseek(f, 0, SEEK_END);
        long size = ftell(f);
        fseek(f, 0, SEEK_SET);
        
        // Creates string dynamically
        char *buff = (char*)malloc(sizeof(char) * (size + 1));
        buff[size] = '\0';
        
        // Sets contents of the string from file
        fread(buff, sizeof(char), size, f);
        
        // Closes file
        fclose(f);
        
        // Returns pointer to array
        return buff;
    } 
    else { 
        // FILE DOES NOT EXIST
        return nullptr;
    }
}