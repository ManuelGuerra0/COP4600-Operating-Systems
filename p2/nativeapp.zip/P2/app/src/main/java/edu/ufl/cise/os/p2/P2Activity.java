package edu.ufl.cise.os.p2;

import android.os.Bundle;
import android.widget.TextView;
import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class P2Activity extends Activity {

    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    // Declare variables for the 3 GUI functions
    private EditText filenameBox;
    private Button submitButton;
    private TextView displayBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_p2);

        // Determines what each GUI element is going to do
        filenameBox = (EditText) findViewById(R.id.filenameBox);
        submitButton = (Button) findViewById(R.id.submitButton);
        displayBox = (TextView) findViewById(R.id.displayBox);

        // SubmitButton is activated when user clicks "Load File"
        submitButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view) {
                // filenameBox takes the user's input
                String input = filenameBox.getText().toString();

                // displayBox invokes Native passing the String input
                // Native returns the jstring and displayBox shows the text
                displayBox.setText(stringFromJNI(input));
            }
        });
    }

    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */

    // Added the String input argument to pass filename to Native
    public native String stringFromJNI(String input);
}